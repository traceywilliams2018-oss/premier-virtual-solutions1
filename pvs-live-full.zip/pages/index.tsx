import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
// ... (omitted for brevity, full canvas code inserted here)
export default function Site() {
  return <div>Premier Virtual Solutions Live Site</div>;
}
